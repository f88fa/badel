// الانتقال إلى صفحة الحجز واختيار الملعب
function goToBookingPage(courtName) {
    localStorage.setItem('selectedCourt', courtName);
    window.location.href = 'confirmation.html';
}

// عرض الملعب المختار في صفحة التأكيد
window.onload = function() {
    const selectedCourt = localStorage.getItem('selectedCourt');
    if (selectedCourt) {
        document.getElementById('selected-court').innerText = selectedCourt;
    }
}

// إرسال الطلب
document.getElementById('submit-btn')?.addEventListener('click', function() {
    const date = document.getElementById('booking-date').value;
    const time = document.getElementById('booking-time').value;
    const termsAccepted = document.getElementById('terms-checkbox').checked;

    if (!date) {
        alert('الرجاء اختيار اليوم.');
        return;
    }

    if (!termsAccepted) {
        alert('الرجاء الموافقة على الشروط والأحكام.');
        return;
    }

    alert(`تم إرسال طلب الحجز بنجاح:\nالملعب: ${localStorage.getItem('selectedCourt')}\nاليوم: ${date}\nالوقت: ${time}`);
});
